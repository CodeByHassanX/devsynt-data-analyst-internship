# Task 3 — SQL, Python & Power BI Business Analysis (Chinook Database)

End-to-end business analysis of the Chinook digital media store: SQL for data extraction, Python
(Pandas + Matplotlib) for analysis and visualization, and Power BI for dashboard reporting.

## Contents

| File / Folder | Description |
|---|---|
| `chinook.db` | Chinook SQLite database used for all analysis |
| `analysis.sql` | 21 SQL queries covering revenue, customers, products, time trends, and segmentation (required: 20+) |
| `analysis.ipynb` | Jupyter notebook — loads SQL results into Pandas and produces 8 visualizations (required: 6+) |
| `chart_*.png` | Exported chart images from the notebook |
| `business_insights.md` | 7 business insights, each with a finding, supporting number, and recommended action |
| `power_bi/` | Power BI-ready data model (CSV star schema) + step-by-step dashboard build guide with DAX measures |
| `build_notebook.py` | Script used to generate `analysis.ipynb` (kept for transparency/reproducibility) |

## How to reproduce

1. **SQL:** Open `analysis.sql` in any SQLite client (or `sqlite3 chinook.db < analysis.sql`) against `chinook.db`.
2. **Python:** `jupyter notebook analysis.ipynb` — all cells run top to bottom against `chinook.db` in the same folder.
3. **Power BI:** Open `power_bi/POWER_BI_GUIDE.md` and follow the steps to import `fact_sales.csv`,
   `dim_customer.csv`, `dim_date.csv` and build the dashboard (KPI cards, 5 charts, 3 slicers) in
   Power BI Desktop. A `.pbix` can't be generated outside Power BI Desktop itself, so the guide
   gives you the exact data model and DAX to build it in ~15-20 minutes.

## Headline numbers

- **Total Revenue:** $2,328.60
- **Total Customers:** 59
- **Total Orders:** 412
- **Average Order Value:** $5.65
- **Top Market:** USA ($523.06, 22.5% of revenue)
- **Top Genre:** Rock (835 units sold)
- **Top Artist:** Iron Maiden (140 units sold)

## SQL concepts used

`SELECT`, `WHERE`, `GROUP BY`, `ORDER BY`, `HAVING`, `JOIN` (INNER/LEFT), `SUM`, `AVG`, `COUNT`,
`CASE`, window functions (`NTILE`), and CTEs / subqueries — used throughout `analysis.sql`,
particularly in the sales-growth (Q14), revenue-contribution (Q19), and customer-segmentation
(Q20-21) queries.

## Notes

- Dataset: [Chinook SQLite Database](https://github.com/lerocha/chinook-database) (customers,
  invoices, tracks, albums, artists, genres, employees).
- Customer value segments (High/Medium/Low) are built with `NTILE(3)` rather than fixed dollar
  thresholds, since per-customer spend in this dataset is tightly clustered (~$36-$50) and fixed
  cut-offs would misclassify most customers into a single tier.
