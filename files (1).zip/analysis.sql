/* ============================================================
   DATA ANALYST INTERNSHIP — TASK 3
   SQL, Python & Power BI Business Analysis
   Database: Chinook (SQLite)
   ============================================================
   Contains 20 queries covering revenue, customers, products,
   time trends, and segmentation. Concepts used across the file:
   SELECT, WHERE, GROUP BY, ORDER BY, HAVING, JOIN, SUM, AVG,
   COUNT, CASE, and CTEs / subqueries.
   ============================================================ */


/* ------------------------------------------------------------
   1. TOTAL REVENUE
   ------------------------------------------------------------ */
SELECT ROUND(SUM(Total), 2) AS TotalRevenue
FROM Invoice;


/* ------------------------------------------------------------
   2. TOTAL CUSTOMERS
   ------------------------------------------------------------ */
SELECT COUNT(*) AS TotalCustomers
FROM Customer;


/* ------------------------------------------------------------
   3. TOTAL ORDERS
   (each Invoice = one order)
   ------------------------------------------------------------ */
SELECT COUNT(*) AS TotalOrders
FROM Invoice;


/* ------------------------------------------------------------
   4. AVERAGE ORDER VALUE
   ------------------------------------------------------------ */
SELECT ROUND(AVG(Total), 2) AS AverageOrderValue
FROM Invoice;


/* ------------------------------------------------------------
   5. AVERAGE SPENDING PER CUSTOMER
   ------------------------------------------------------------ */
SELECT ROUND(SUM(i.Total) * 1.0 / COUNT(DISTINCT i.CustomerId), 2) AS AvgSpendPerCustomer
FROM Invoice i;


/* ------------------------------------------------------------
   6. TOP 10 CUSTOMERS BY SPENDING
   ------------------------------------------------------------ */
SELECT
    c.CustomerId,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    c.Country,
    ROUND(SUM(i.Total), 2) AS TotalSpent
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.CustomerId, CustomerName, c.Country
ORDER BY TotalSpent DESC
LIMIT 10;


/* ------------------------------------------------------------
   7. REVENUE BY COUNTRY
   ------------------------------------------------------------ */
SELECT
    c.Country,
    ROUND(SUM(i.Total), 2) AS Revenue
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.Country
ORDER BY Revenue DESC;


/* ------------------------------------------------------------
   8. CUSTOMER COUNT BY COUNTRY
   ------------------------------------------------------------ */
SELECT
    Country,
    COUNT(*) AS CustomerCount
FROM Customer
GROUP BY Country
ORDER BY CustomerCount DESC;


/* ------------------------------------------------------------
   9. TOP-SELLING GENRES (by quantity sold)
   ------------------------------------------------------------ */
SELECT
    g.Name AS Genre,
    SUM(il.Quantity) AS UnitsSold,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM Genre g
JOIN Track t ON g.GenreId = t.GenreId
JOIN InvoiceLine il ON t.TrackId = il.TrackId
GROUP BY g.Name
ORDER BY UnitsSold DESC
LIMIT 10;


/* ------------------------------------------------------------
   10. TOP-SELLING ARTISTS (by quantity sold)
   ------------------------------------------------------------ */
SELECT
    ar.Name AS Artist,
    SUM(il.Quantity) AS UnitsSold,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM Artist ar
JOIN Album al ON ar.ArtistId = al.ArtistId
JOIN Track t ON al.AlbumId = t.AlbumId
JOIN InvoiceLine il ON t.TrackId = il.TrackId
GROUP BY ar.Name
ORDER BY UnitsSold DESC
LIMIT 10;


/* ------------------------------------------------------------
   11. TOP-SELLING TRACKS (by quantity sold)
   ------------------------------------------------------------ */
SELECT
    t.Name AS Track,
    ar.Name AS Artist,
    SUM(il.Quantity) AS UnitsSold,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM Track t
JOIN InvoiceLine il ON t.TrackId = il.TrackId
JOIN Album al ON t.AlbumId = al.AlbumId
JOIN Artist ar ON al.ArtistId = ar.ArtistId
GROUP BY t.TrackId, t.Name, ar.Name
ORDER BY UnitsSold DESC
LIMIT 10;


/* ------------------------------------------------------------
   12. REVENUE BY YEAR
   ------------------------------------------------------------ */
SELECT
    STRFTIME('%Y', InvoiceDate) AS Year,
    ROUND(SUM(Total), 2) AS Revenue
FROM Invoice
GROUP BY Year
ORDER BY Year;


/* ------------------------------------------------------------
   13. REVENUE BY MONTH (across all years, month number)
   ------------------------------------------------------------ */
SELECT
    STRFTIME('%m', InvoiceDate) AS Month,
    ROUND(SUM(Total), 2) AS Revenue
FROM Invoice
GROUP BY Month
ORDER BY Month;


/* ------------------------------------------------------------
   14. MONTHLY / YEARLY SALES GROWTH
   Uses a CTE to build a monthly revenue series, then compares
   each month to the previous month with a self-join.
   ------------------------------------------------------------ */
WITH MonthlyRevenue AS (
    SELECT
        STRFTIME('%Y-%m', InvoiceDate) AS YearMonth,
        ROUND(SUM(Total), 2) AS Revenue
    FROM Invoice
    GROUP BY YearMonth
)
SELECT
    cur.YearMonth,
    cur.Revenue,
    prev.Revenue AS PrevMonthRevenue,
    ROUND(
        (cur.Revenue - prev.Revenue) * 100.0 / NULLIF(prev.Revenue, 0), 2
    ) AS GrowthPercent
FROM MonthlyRevenue cur
LEFT JOIN MonthlyRevenue prev
    ON prev.YearMonth = STRFTIME('%Y-%m', DATE(cur.YearMonth || '-01', '-1 month'))
ORDER BY cur.YearMonth;


/* ------------------------------------------------------------
   15. HIGHEST-PERFORMING COUNTRY
   ------------------------------------------------------------ */
SELECT
    c.Country,
    ROUND(SUM(i.Total), 2) AS Revenue
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.Country
ORDER BY Revenue DESC
LIMIT 1;


/* ------------------------------------------------------------
   16. HIGHEST-PERFORMING MONTH
   ------------------------------------------------------------ */
SELECT
    STRFTIME('%Y-%m', InvoiceDate) AS YearMonth,
    ROUND(SUM(Total), 2) AS Revenue
FROM Invoice
GROUP BY YearMonth
ORDER BY Revenue DESC
LIMIT 1;


/* ------------------------------------------------------------
   17. HIGHEST-PERFORMING ARTIST
   ------------------------------------------------------------ */
SELECT
    ar.Name AS Artist,
    ROUND(SUM(il.UnitPrice * il.Quantity), 2) AS Revenue
FROM Artist ar
JOIN Album al ON ar.ArtistId = al.ArtistId
JOIN Track t ON al.AlbumId = t.AlbumId
JOIN InvoiceLine il ON t.TrackId = il.TrackId
GROUP BY ar.Name
ORDER BY Revenue DESC
LIMIT 1;


/* ------------------------------------------------------------
   18. CUSTOMERS WITH HIGHEST PURCHASE FREQUENCY
   (most number of distinct orders/invoices)
   ------------------------------------------------------------ */
SELECT
    c.CustomerId,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    COUNT(i.InvoiceId) AS OrderCount
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.CustomerId, CustomerName
HAVING COUNT(i.InvoiceId) > 1
ORDER BY OrderCount DESC
LIMIT 10;


/* ------------------------------------------------------------
   19. REVENUE CONTRIBUTION OF TOP CUSTOMERS
   Uses a subquery to compare each of the top 10 customers'
   spend against total company revenue.
   ------------------------------------------------------------ */
SELECT
    CustomerName,
    TotalSpent,
    ROUND(TotalSpent * 100.0 / (SELECT SUM(Total) FROM Invoice), 2) AS PctOfTotalRevenue
FROM (
    SELECT
        c.FirstName || ' ' || c.LastName AS CustomerName,
        SUM(i.Total) AS TotalSpent
    FROM Customer c
    JOIN Invoice i ON c.CustomerId = i.CustomerId
    GROUP BY c.CustomerId, CustomerName
    ORDER BY TotalSpent DESC
    LIMIT 10
) AS TopCustomers
ORDER BY TotalSpent DESC;


/* ------------------------------------------------------------
   20. HIGH, MEDIUM AND LOW-VALUE CUSTOMER SEGMENTS
   Uses a CTE for per-customer spend, then NTILE(3) (a window
   function) to split customers into three equal-sized value
   tiers by spend rank, and a CASE expression to label them.
   NTILE is used instead of fixed dollar cut-offs because
   Chinook's per-customer spend is tightly clustered
   (~$36-$50), so fixed thresholds would misclassify almost
   everyone into one tier.
   ------------------------------------------------------------ */
WITH CustomerSpend AS (
    SELECT
        c.CustomerId,
        c.FirstName || ' ' || c.LastName AS CustomerName,
        c.Country,
        SUM(i.Total) AS TotalSpent
    FROM Customer c
    JOIN Invoice i ON c.CustomerId = i.CustomerId
    GROUP BY c.CustomerId, CustomerName, c.Country
),
Ranked AS (
    SELECT
        *,
        NTILE(3) OVER (ORDER BY TotalSpent DESC) AS SpendTier
    FROM CustomerSpend
)
SELECT
    CustomerId,
    CustomerName,
    Country,
    ROUND(TotalSpent, 2) AS TotalSpent,
    CASE SpendTier
        WHEN 1 THEN 'High-Value'
        WHEN 2 THEN 'Medium-Value'
        ELSE 'Low-Value'
    END AS ValueSegment
FROM Ranked
ORDER BY TotalSpent DESC;


/* ------------------------------------------------------------
   BONUS 21. CUSTOMER COUNT PER VALUE SEGMENT
   (rollup of query 20 — useful for the Power BI KPI/segment card)
   ------------------------------------------------------------ */
WITH CustomerSpend AS (
    SELECT
        c.CustomerId,
        SUM(i.Total) AS TotalSpent
    FROM Customer c
    JOIN Invoice i ON c.CustomerId = i.CustomerId
    GROUP BY c.CustomerId
),
Ranked AS (
    SELECT
        *,
        NTILE(3) OVER (ORDER BY TotalSpent DESC) AS SpendTier
    FROM CustomerSpend
),
Segmented AS (
    SELECT
        TotalSpent,
        CASE SpendTier
            WHEN 1 THEN 'High-Value'
            WHEN 2 THEN 'Medium-Value'
            ELSE 'Low-Value'
        END AS ValueSegment
    FROM Ranked
)
SELECT
    ValueSegment,
    COUNT(*) AS NumberOfCustomers,
    ROUND(SUM(TotalSpent), 2) AS SegmentRevenue,
    ROUND(AVG(TotalSpent), 2) AS AvgSpendInSegment
FROM Segmented
GROUP BY ValueSegment
ORDER BY SegmentRevenue DESC;
