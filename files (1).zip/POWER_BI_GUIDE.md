# Power BI Dashboard — Build Guide

> **Note on the .pbix file:** Power BI Desktop is a Windows GUI application, so a `.pbix` binary
> can't be produced in this code environment. Instead, this folder gives you a ready-to-import
> star-schema data model (CSV files, already cleaned and joined from the SQL analysis) plus every
> DAX measure and layout instruction needed to build the dashboard in Power BI Desktop in about
> 15-20 minutes. Follow the steps below and save as `dashboard.pbix`.

## 1. Files in this folder

| File | Grain | Use |
|---|---|---|
| `fact_sales.csv` | One row per invoice line (2,240 rows) | Fact table — revenue, quantity, genre, artist, country, date |
| `dim_customer.csv` | One row per customer (59 rows) | Customer name, country, total spent, order count, value segment |
| `dim_date.csv` | One row per invoice date (354 rows) | Year / month name / year-month for the date slicer and trend charts |

## 2. Import & model

1. Power BI Desktop → **Get Data → Text/CSV** → import all three files.
2. Go to **Model view** and create relationships:
   - `fact_sales[CustomerId]` → `dim_customer[CustomerId]` (many-to-one)
   - `fact_sales[InvoiceDate]` → `dim_date[Date]` (many-to-one) — you may need to truncate
     `fact_sales.InvoiceDate` to a date-only column first: add a calculated column
     `SaleDate = DATEVALUE(LEFT(fact_sales[InvoiceDate], 10))` and relate on that instead.
3. Set data types: `LineTotal`, `UnitPrice` → Decimal; `Quantity` → Whole number; `Year`,
   `MonthNum` → Whole number.

## 3. DAX measures to create (on `fact_sales`)

```dax
Total Revenue = SUM(fact_sales[LineTotal])

Total Orders = DISTINCTCOUNT(fact_sales[InvoiceId])

Total Customers = DISTINCTCOUNT(fact_sales[CustomerId])

Average Order Value =
DIVIDE([Total Revenue], [Total Orders])

Average Spend per Customer =
DIVIDE([Total Revenue], [Total Customers])

Revenue LY =
CALCULATE([Total Revenue], SAMEPERIODLASTYEAR(dim_date[Date]))

Revenue Growth % =
DIVIDE([Total Revenue] - [Revenue LY], [Revenue LY])
```

## 4. KPI cards (top row)

Four **Card** visuals using: `Total Revenue`, `Total Orders`, `Total Customers`,
`Average Order Value`. Format Total Revenue as currency ($#,##0.00).

## 5. Required visuals (minimum 5)

| Visual | Type | Fields |
|---|---|---|
| Revenue by Country | Bar chart | Axis: `dim_customer[Country]`, Value: `Total Revenue` |
| Sales Trend | Line chart | Axis: `dim_date[YearMonth]`, Value: `Total Revenue` |
| Top 10 Customers | Bar chart | Axis: `dim_customer[FirstName]+[LastName]`, Value: `Total Revenue`, Top N filter = 10 |
| Revenue by Genre | Bar or Treemap | Axis: `fact_sales[Genre]`, Value: `Total Revenue` |
| Top Artists / Customer Distribution | Bar chart | Axis: `fact_sales[Artist]` or `dim_customer[Country]` count, Value: `Total Revenue` or customer count |

## 6. Filters / Slicers

Add three **Slicer** visuals at the top or side of the report:
- `dim_customer[Country]`
- `dim_date[Year]`
- `fact_sales[Genre]`

## 7. Layout & quality checklist

- Arrange KPI cards in a single row at the top; visuals in a 2-3 column grid below.
- Use one consistent color per category (e.g., genre colors stay the same across all charts).
- Label axes and enable data labels on bar charts for readability.
- Set the report theme (View → Themes) for a consistent, professional palette.
- Test each slicer to confirm all visuals cross-filter correctly, then save as `dashboard.pbix`.

## 8. Reference numbers (from the SQL analysis, for a sanity check once loaded)

- Total Revenue: **$2,328.60**
- Total Orders: **412**
- Total Customers: **59**
- Average Order Value: **$5.65**
- Top country by revenue: **USA ($523.06)**
