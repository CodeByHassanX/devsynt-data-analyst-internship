# Business Insights — Chinook Store Analysis

Data source: Chinook digital media store database (59 customers, 412 orders, $2,328.60 total revenue).

---

### 1. Revenue is heavily concentrated in North America
**Finding:** The USA and Canada together generate the largest share of store revenue, far ahead of any other market.
**Supporting value:** USA = $523.06 (22.5% of total revenue), Canada = $303.96 (13.1%) — combined ~35.6% of the $2,328.60 total.
**Recommended action:** Prioritize retention campaigns, loyalty offers, and localized marketing spend in the USA and Canada, since they carry the most revenue risk and upside.

---

### 2. A small group of top customers drives a disproportionate share of revenue
**Finding:** The top 10 customers by spend contribute far more than their 17% share of the 59-customer base would suggest.
**Supporting value:** Top 10 customers = $451.20, or 19.4% of total revenue, from just 17% of customers.
**Recommended action:** Set up a VIP/loyalty program for these high-value accounts (early access, discounts, personal outreach) to protect this concentrated revenue stream from churn.

---

### 3. Rock dominates genre sales, with Latin and Metal as secondary strengths
**Finding:** Rock is by far the best-selling genre by units sold, more than double the next closest genre.
**Supporting value:** Rock = 835 units ($826.65), Latin = 386 units ($382.14), Metal = 264 units ($261.36).
**Recommended action:** Expand the Rock catalog and feature it prominently in promotions and playlists; use Latin and Metal as targeted secondary campaigns rather than broad-based ones.

---

### 4. Iron Maiden is the single highest-performing artist
**Finding:** Iron Maiden leads all artists in both units sold and revenue, ahead of U2 and Metallica.
**Supporting value:** Iron Maiden = 140 units ($138.60) vs. U2 = 107 units ($105.93) and Metallica = 91 units ($90.09).
**Recommended action:** Use Iron Maiden (and similar top-tier rock/metal artists) as anchor content in homepage features, bundles, and email campaigns to drive incremental purchases.

---

### 5. Revenue is stable year over year with no major growth trend
**Finding:** Annual revenue has stayed in a narrow band across the five years of data, without a clear upward trajectory.
**Supporting value:** 2021 = $449.46, 2022 = $481.45, 2023 = $469.58, 2024 = $477.53, 2025 = $450.58 (a range of roughly $32, or ~7% of the average).
**Recommended action:** Since organic growth is flat, invest in active growth levers — new releases, bundle pricing, and re-engagement campaigns for lapsed customers — rather than relying on existing demand to expand revenue.

---

### 6. Customer value is evenly distributed across three clear tiers
**Finding:** Splitting customers into High/Medium/Low value tiers by total spend shows a fairly even three-way split, with High-Value customers still spending meaningfully more per head.
**Supporting value:** High-Value: 20 customers, $852.40 (avg $42.62/customer); Medium-Value: 20 customers, $762.40 (avg $38.12); Low-Value: 19 customers, $713.80 (avg $37.57).
**Recommended action:** Build tiered marketing: exclusive perks for High-Value customers, upsell/cross-sell nudges for Medium-Value customers, and reactivation offers for Low-Value customers to move them up a tier.

---

### 7. A handful of customers purchase far more frequently than average
**Finding:** While the typical customer orders only a few times, a set of customers places noticeably more orders than the rest, indicating strong loyalty potential.
**Supporting value:** Several customers (e.g., Luís Gonçalves, Leonie Köhler, François Tremblay, Bjørn Hansen, František Wichterlová) each placed 7 orders — well above the average of ~7 orders per customer overall (412 orders / 59 customers), with a long tail of customers ordering only once or twice.
**Recommended action:** Analyze what drives repeat purchases from these high-frequency customers (genre preferences, promotions used) and replicate those triggers — targeted emails, recommended tracks, seasonal promos — across the broader customer base to lift overall order frequency.
